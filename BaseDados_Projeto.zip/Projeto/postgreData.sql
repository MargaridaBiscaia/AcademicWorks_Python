insert into "AMprojeto_fabricante" (id, cc, nome, nacionalidade, datanasc, datafal)
values
(1, 1, 'William Morgan', 'Americana', '23/01/1870', '27/02/1942'),
(2, 2, 'Charles Miller', 'Brasileira', '24/11/1874', '30/05/1953');

insert into "AMprojeto_jogador" (id, cc, nome, nacionalidade, datanasc, datafal)
values
(1, 1, 'Miguel Tavares', 'Portuguesa', '02/03/1993', null),
(2, 2, 'Otavio Monteiro', 'Brasileira', '09/02/1995', null);

insert into "AMprojeto_bola" (fabricante_id, id, id_bola, tipo, data_criacao, design, tamanho)
values
((select cc from "AMprojeto_fabricante" where nome = 'William Morgan'), 1, 1, 'Voleibol', 1895, 'Redonda,Amarela e Azul', 65),
((select cc from "AMprojeto_fabricante" where nome = 'Charles Miller'), 2, 2, 'Futebol', 1884, 'Redonda', 69);

insert into "AMprojeto_imagens" (bola_id, id_imagem, imagem)
values
((select p.id_bola from "AMprojeto_bola" p where  p.tipo='Voleibol'), 1, 'https://www.mikasa.pt/wp-content/uploads/Bola-de-Voleibol-Mikasa-V200W.png'),
((select p.id_bola from "AMprojeto_bola" p where  p.tipo='Futebol'), 2, 'https://ouremsport.com/image/cache/data/select/S45.958.46.121_2-800x800.jpg');

insert into "AMprojeto_jogo" (bola_id, jogador_id, id_jogo, data, nomeequipa1, nomeequipa2)
values
(
	(select p.id_bola from "AMprojeto_bola" p where  p.tipo='Voleibol'),
	(select cc from "AMprojeto_jogador" where nome='Miguel Tavares'),
	2, '20/12/2021', 'Aluron CMC', 'Asseco Resovia'
),
(
	(select p.id_bola from "AMprojeto_bola" p where  p.tipo='Futebol'),
	(select cc from "AMprojeto_jogador" where nome='Otavio Monteiro'),
	1, '30/12/2021', 'FCPorto', 'SLBenfica'
);
