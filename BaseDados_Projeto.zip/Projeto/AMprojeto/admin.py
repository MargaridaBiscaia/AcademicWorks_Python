from django.contrib import admin
from import_export.admin import ImportExportModelAdmin

# Register your models here.
from .models import Fabricante
from .models import Bola
from .models import Jogador
from .models import Imagens
from .models import Jogo

admin.site.register(Fabricante)
admin.site.register(Bola)
admin.site.register(Jogador)
admin.site.register(Imagens)
admin.site.register(Jogo)