from django.shortcuts import render
from django.template import loader
from django.http import HttpResponse, Http404

from .models import Fabricante
from .models import Bola
from .models import Jogador
from .models import Imagens
from .models import Jogo

def index(request):
    template = loader.get_template('AMprojeto/index.html')
    context = {
        'numFabricantes':Fabricante.objects.all().count(),
        'numBolas':Bola.objects.all().count(),
        'numJogadores':Jogador.objects.all().count(),
        'numJogos':Jogo.objects.all().count(),
        'numImagem':Imagens.objects.all().count(),
    }
    return HttpResponse(template.render(context, request))

def Fabricantes(request):
    template = loader.get_template('AMprojeto/fabricantes.html')
    items = Fabricante.objects.order_by('nome')[0:]
    context = {
        'fabricantes':items
    }
    return HttpResponse(template.render(context, request))

def FabricanteDetalhes(request, fabricante_cc):
    template = loader.get_template('AMprojeto/fabricanteDetalhes.html')
    try:
        myFabricante = Fabricante.objects.get(pk=fabricante_cc)
        myFabricanteBolas = Bola.objects.filter(fabricante = fabricante_cc)
        context = {'fabricante' : myFabricante, 'bolas' : myFabricanteBolas}
    except Fabricante.DoesNotExist:
        raise Http404("Fabricante nao existe.")

    return HttpResponse(template.render(context, request))


def Jogadores(request):
    template = loader.get_template('AMprojeto/jogadores.html')
    items = Jogador.objects.order_by('nome')[0:]
    context = {
        'jogadores':items
    }
    return HttpResponse(template.render(context, request))

def JogadorDetalhes(request, jogador_cc):
    template = loader.get_template('AMprojeto/jogadorDetalhes.html')
    try:
        myJogador = Jogador.objects.get(pk=jogador_cc)
        myJogos = Jogo.objects.filter(jogador = jogador_cc)
        context = {'jogador' : myJogador, 'jogos' : myJogos}
    except Jogador.DoesNotExist:
        raise Http404("Jogador nao existe.")

    return HttpResponse(template.render(context, request))

def Bolas(request):
    template = loader.get_template('AMprojeto/bolas.html')
    items = Bola.objects.order_by('fabricante', 'tipo')[0:]
    context = {
        'bolas':items
    }
    return HttpResponse(template.render(context, request))

def Imagem(request):
    template = loader.get_template('AMprojeto/imagens.html')
    items = Imagens.objects.order_by('bola', 'imagem')[0:]
    context = {
        'imagens':items
    }
    return HttpResponse(template.render(context, request))

def BolaDetalhes(request, bola_id_bola):
    template = loader.get_template('AMprojeto/bolaDetalhes.html')
    try:
        bola = Bola.objects.get(pk = bola_id_bola)
        myImagens = Imagens.objects.filter(bola = bola_id_bola)
        context = {'bola' : bola, 'imagens' : myImagens}
    except Bola.DoesNotExist:
        raise Http404("Bola nao existe")
    return HttpResponse(template.render(context, request))

def Jogos(request):
    template = loader.get_template('AMprojeto/jogos.html')
    items = Jogo.objects.order_by('jogador', 'id_jogo')[0:]
    context = {
        'jogos':items
    }
    return HttpResponse(template.render(context, request))

def JogoDetalhes(request, jogo_id_jogo):
    template = loader.get_template('AMprojeto/jogoDetalhes.html')
    try:
        jogo = Jogo.objects.get(id_jogo = jogo_id_jogo)
        context = {'jogo' : jogo}
    except Jogo.DoesNotExist:
        raise Http404("Jogo nao existe")
    return HttpResponse(template.render(context, request))
