from django.db import models

class Fabricante(models.Model):
    cc = models.IntegerField(null=False, blank=False)
    nome = models.CharField(max_length=20, null=False, blank=False)
    nacionalidade = models.CharField(max_length=20, null=True, blank=True)
    datanasc = models.CharField(max_length=20, null=True, blank=True)
    datafal = models.CharField(max_length=20, null=True, blank=True)
    def __str__(self):
        return self.nome
    def isAlive(self):
        return dataFal==False

class Bola(models.Model):
    fabricante = models.ForeignKey(Fabricante, on_delete=models.CASCADE)
    id_bola = models.IntegerField(null=False, blank=False)
    tipo = models.CharField(max_length = 20, null=False, blank=False)
    data_criacao = models.CharField(max_length=20, null=True, blank=True)
    design = models.CharField(max_length=200, null=True, blank=True)
    tamanho = models.FloatField(null=True, blank=True)
    def __str__(self):
        return self.fabricante.nome+"-"+self.tipo

class Imagens(models.Model):
    id_imagem = models.IntegerField(null=False, blank=False)
    imagem = models.URLField(max_length=500, null=False, blank=False)
    bola = models.ForeignKey(Bola, on_delete=models.CASCADE)
    def __str__(self):
        return self.imagem

class Jogador(models.Model):
    cc = models.IntegerField(null=False, blank=False)
    nome = models.CharField(max_length=20, null=False, blank=False)
    nacionalidade = models.CharField(max_length=20, null=True, blank=True)
    datanasc = models.CharField(max_length=20, null=True, blank=True)
    datafal = models.CharField(max_length=20, null=True, blank=True)
    def __str__(self):
        return self.nome
    def isAlive(self):
        return dataFal==False

class Jogo(models.Model):
    id_jogo = models.IntegerField(null=False, blank=False)
    data = models.CharField(max_length=20, null=False, blank=False)
    nomeequipa1 = models.CharField(max_length=200, null=True, blank=True)
    nomeequipa2 = models.CharField(max_length=200, null=True, blank=True)
    bola = models.ForeignKey(Bola, on_delete=models.CASCADE)
    jogador = models.ForeignKey(Jogador, on_delete=models.CASCADE, null=True, blank=True)
    def __str__(self):
        return self.data
