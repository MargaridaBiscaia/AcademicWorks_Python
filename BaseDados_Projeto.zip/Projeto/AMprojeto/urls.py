from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),

    #fabricantes
    path('fabricantes', views.Fabricantes, name='fabricantes'),
    path('fabricantes/<int:fabricante_cc>/', views.FabricanteDetalhes, name='fabricanteDetalhes'),

    #jogadores
    path('jogadores', views.Jogadores, name='jogadores'),
    path('jogadores/<int:jogador_cc>/', views.JogadorDetalhes, name='jogadorDetalhes'),

    #jogos
    path('jogos', views.Jogos, name='jogos'),
    path('jogos/<int:jogo_id_jogo>/', views.JogoDetalhes, name='jogoDetalhes'),

    #bolas
    path('bolas', views.Bolas, name='bolas'),
    path('bolas/<int:bola_id_bola>/', views.BolaDetalhes, name='bolaDetalhes'),

    #imagem
    path('imagem', views.Imagem, name='imagem'),
]